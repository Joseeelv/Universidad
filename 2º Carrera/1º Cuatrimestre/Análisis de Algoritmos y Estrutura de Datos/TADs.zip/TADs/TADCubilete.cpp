/*
Especificación del TAD
*/