#include "TADCartelera.hpp"

int main() {
    Cartelera cartelera;
    cartelera.setSala(1);
    cartelera.setSala(2);
    cartelera.setSala(3);

    cartelera.setEspectaculo(1,"Pepito el caja");

    return 0;
}