from busquedaAlum import *

objetivo = busquedaProfundidadLimitada(4)
if objetivo:
    print("Se ha alcanzado una solución")
else:
    print("No se ha alcanzado ninguna solución")
