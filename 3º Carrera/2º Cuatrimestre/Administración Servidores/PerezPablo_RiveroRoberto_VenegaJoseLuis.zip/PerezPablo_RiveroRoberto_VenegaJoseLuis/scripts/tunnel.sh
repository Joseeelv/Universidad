#!/bin/bash

LOG_FILE="/var/log/tunnel.log"

# Configuración
DEV_HOST="172.40.0.2"         # IP del contenedor destino (dev)
DEV_FTP_PORT="21"             # Puerto del servidor FTP destino
LOCAL_FTP_PORT="2121"         # Puerto local a redirigir
REMOTE_USER="user"            # Usuario SSH
REMOTE_HOST="servidor_dev"    # Nombre del host o contenedor accesible por SSH

# Función de log
log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

# Asegurar entrada en /etc/hosts
grep -q "$DEV_HOST $REMOTE_HOST" /etc/hosts || echo "$DEV_HOST $REMOTE_HOST" >> /etc/hosts

# Matar túnel anterior si existe
if [ -f /var/run/tunnel.pid ]; then
    OLD_PID=$(cat /var/run/tunnel.pid)
    if ps -p "$OLD_PID" > /dev/null; then
        log "Matando túnel SSH anterior (PID $OLD_PID)..."
        kill "$OLD_PID"
    fi
    rm -f /var/run/tunnel.pid
fi

# Establecer nuevo túnel
log "Estableciendo túnel SSH: localhost:$LOCAL_FTP_PORT → $DEV_HOST:$DEV_FTP_PORT"
ssh -N -L "$LOCAL_FTP_PORT:$DEV_HOST:$DEV_FTP_PORT" "$REMOTE_USER@$REMOTE_HOST" &
SSH_PID=$!

# Verificar si el túnel se inició
sleep 2
if ps -p "$SSH_PID" > /dev/null; then
    echo "$SSH_PID" > /var/run/tunnel.pid
    log "Túnel SSH iniciado correctamente con PID $SSH_PID"
else
    log "ERROR: Falló el inicio del túnel SSH"
    exit 1
fi
