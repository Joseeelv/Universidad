#ifndef _SALTOS_H_
#define _SALTOS_H_

void quitar_saltos(char *);
#endif